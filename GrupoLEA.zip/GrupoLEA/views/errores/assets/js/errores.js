$(document).ready(function () {

    
$('#close').click(function(){
    window.close();
});

});