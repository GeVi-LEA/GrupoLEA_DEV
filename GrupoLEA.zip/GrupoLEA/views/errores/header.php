<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grupo LEA de México</title>
        <link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css"> 
        <link rel="stylesheet" href="assets/fonts/material-icons/css/material-icons.css">
        <link rel="stylesheet" href="<?=root_url?>views/errores/assets/css/errores.css"> 
        <script src="assets/js/jquery-3.5.1.min.js"></script>
        <script src="<?=root_url?>views/errores/assets/js/errores.js"></script>
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
    </head>
    <body>
        <div class="container fondo">