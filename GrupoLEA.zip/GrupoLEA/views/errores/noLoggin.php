<?php require_once 'header.php'; ?>    

            <div class="row">
                <div class="col-12 content">
                    <span class='material-icons i-danger'>dangerous</span>
                    <h1>Tu sesión expiró</h1>
                    <div><a href="<?php echo $inicio ?>">Iniciar sesión</a></div>
                </div>
            </div>
<?php require_once 'footer.php'; ?>    