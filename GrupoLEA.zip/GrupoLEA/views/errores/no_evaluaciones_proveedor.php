<?php require_once 'header.php'; ?>    
            <div class="row">
                <div class="col-12 content">
                    <span class='material-icons i-danger'>dangerous</span>
                    <h1>El proveedor no tiene compras en el período.</h1>
                    <div><a id="close" href="">Cerrar</a></div>
                </div>
            </div>
<?php require_once 'footer.php'; ?>    
