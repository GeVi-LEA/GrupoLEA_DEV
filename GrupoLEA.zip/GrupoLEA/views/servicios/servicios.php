<div class="principal-titulo"><h3>Servicios</h3></div>
<div class="div-servicios">
    <div><a href="<?=principalUrl?>?controller=Servicios&action=ensacado"><span>CARGAS / DESCARGAS</span></a></div>
    <div><a href="<?=principalUrl?>?controller=Servicios&action=serviciosNave"><span>SERVICIOS NAVE 4</span></a></div>
    <div><a href="<?=principalUrl?>?controller=Servicios&action=serviciosAlmacen"><span>ALMACENAJE</span></a></div>
    <div><span>RENTA DE PISO</span></div>
    <div><span>RENTA ESPUELA</span></div> 
    <div><span>TRASVASE</span></div> 
    <div><span>REEMPAQUE</span></div> 
    <div><span>PESAJES</span></div> 
    <div><span>RENTA ESPUELA</span></div> 
</div>
<script src="<?= root_url ?>views/servicios/assets/js/servicios.js"></script>
          